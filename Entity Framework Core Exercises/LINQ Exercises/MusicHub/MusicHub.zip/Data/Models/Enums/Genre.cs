﻿namespace MusicHub.Data.Models
{
    public enum Genre
    {
        Blues,
        Rap,
        PopMusic,
        Rock,
        Jazz
    }
}

//Blues, Rap, PopMusic, Rock, Jazz
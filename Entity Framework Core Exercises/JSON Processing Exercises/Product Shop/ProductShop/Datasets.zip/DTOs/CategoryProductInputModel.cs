﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs
{
    public class CategoryProductInputModel
    {
        public int ProductId { get; set; }

        public int CategoryId { get; set; }

    }
}
